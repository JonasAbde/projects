[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/SbgH9FA6)

# Wordle

Skabelon til [Wordle](https://www.nytimes.com/games/wordle/index.html) - [Notion beskrivelse](https://mercantec.notion.site/Wordle-101117d07e79459c8fc5b74e6984516a?pvs=4)

Spillets Regler:
Gæt Bogstaver:

Brug dit tastatur til at gætte bogstaver i det skjulte ord.
Hver række har fem bokse, og du skal gætte det rigtige ord ved at indtaste fem bogstaver.
Resultat og Feedback:

Efter hvert gæt vises resultatet i boksene. Korrekte bogstaver vises, og du kan følge din fremgang.
Hvis du gætter alle fem bogstaver korrekt, går du videre til næste række.
Vind Spillet:

Gennemfør alle fem rækker for at vinde spillet.
Efter fem rækker bliver du informeret om, at du har gennemført spillet.
Nulstil og Prøv Igen:

Gør du en fejl, får du besked om det, og boksene nulstilles for den aktuelle række.
Du kan prøve igen og fortsætte med at gætte.
